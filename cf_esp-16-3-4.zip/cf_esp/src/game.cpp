#include "game.h"
#include <chrono>
#include <cstring>
#include <unordered_map>

static double now_s() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}

static bool finite3(Vec3 v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); }

bool Game::resolve() {
    if (!kCull_) kCull_ = il_.klass(off::PlayerCulling::cls);
    if (!kFps_)  kFps_  = il_.klass(off::PlayerFPSCamera::cls);
    if (!kLife_) kLife_ = il_.klass(off::LifeState::cls);
    cullStatics_ = il_.statics(kCull_);
    fpsStatics_  = il_.statics(kFps_);
    status_ = !kCull_ ? "no PlayerCulling class (il2cpp structs seen: " + std::to_string(il_.classes_seen()) + ")" : !cullStatics_ ? "PlayerCulling statics null (cctor not run)" : "ok";
    return kCull_ && cullStatics_;
}

// LifeState has no static handle we can reach from a klass slot (it hangs off the PlayerLife singleton),
// so locate the instance by scanning for objects whose first word is the LifeState klass.
bool Game::find_life() {
    if (!kLife_) return false;
    auto valid = [&](uint64_t o) {
        uint64_t items; uint32_t n;
        if (rdp(m_, o) != kLife_) return false;
        if (!il_.list(rdp(m_, o + off::LifeState::_entries), items, n, 64)) return false;
        return n > 0;
    };
    uint64_t best = 0; uint32_t bestN = 0;
    for (uint64_t o : il_.find_instances(kLife_, valid)) {
        uint64_t items; uint32_t n;
        il_.list(rdp(m_, o + off::LifeState::_entries), items, n, 64);
        if (n >= bestN) { best = o; bestN = n; }
    }
    life_ = best;
    return life_ != 0;
}

// TeammateLabels (HUD) keeps `_mates`: the game's own list of teammates. Used as a second source for the teammate check.
bool Game::find_labels() {
    if (!kLabels_) kLabels_ = il_.klass(off::TeammateLabels::cls);
    if (!kLabels_) return false;
    auto valid = [&](uint64_t o) { uint64_t items; uint32_t n; return rdp(m_, o) == kLabels_ && il_.list(rdp(m_, o + off::TeammateLabels::_mates), items, n, 64); };
    uint64_t best = 0;
    for (uint64_t o : il_.find_instances(kLabels_, valid)) best = o;
    labels_ = best;
    return labels_ != 0;
}

bool Game::update(Snapshot& s) {
    s.valid = false; s.haveLocal = false; s.localActor = 0; s.localTeam = 0; s.lifeOk = false;
    s.players.clear();
    if (!cullStatics_ && !resolve()) return false;

    // --- camera (statics of PlayerCulling are refreshed by the game every frame)
    Vec3 pos = rdv<Vec3>(m_, cullStatics_ + off::PlayerCulling::s__cameraPosition);
    Vec3 fwd = rdv<Vec3>(m_, cullStatics_ + off::PlayerCulling::s__cameraForward);
    bool hasCam = rd8(m_, cullStatics_ + off::PlayerCulling::s__hasCamera) != 0;
    float fl = len(fwd);
    if (!hasCam || !finite3(pos) || !finite3(fwd) || fl < 0.9f || fl > 1.1f) { status_ = "no camera"; return false; }
    s.cam.pos = pos; s.cam.fwd = fwd;
    float fov = 0;
    if (fpsStatics_) {
        uint64_t loc = rdp(m_, fpsStatics_ + off::PlayerFPSCamera::s_Local);
        if (plausible_ptr(loc)) fov = rdf(m_, loc + off::PlayerFPSCamera::BaseFieldOfView);
    }
    s.cam.fovY = (fov > 20.f && fov < 140.f) ? fov : 60.f;

    // --- players
    uint64_t items; uint32_t n;
    if (!il_.list(rdp(m_, cullStatics_ + off::PlayerCulling::s_Instances), items, n, 64)) { status_ = "bad Instances"; return false; }
    uint64_t ptrs[64] = {0};
    if (n && !m_.read(items + il2::ARR_DATA, ptrs, n * 8)) { status_ = "bad Instances array"; return false; }

    // --- hp/team table: actor -> LifeEntry
    std::unordered_map<int, std::pair<int, uint8_t>> life;   // hp, team (+alive folded into hp<=0)
    s.lifeOk = false;
    if (kLife_) {
        uint64_t litems; uint32_t ln;
        bool ok = life_ && rdp(m_, life_) == kLife_ && il_.list(rdp(m_, life_ + off::LifeState::_entries), litems, ln, 64);
        if (!ok && n > 0 && now_s() >= nextLifeScan_) { find_life(); nextLifeScan_ = now_s() + 5.0; }   // heap scan: only in a match, throttled
        if (life_ && rdp(m_, life_) == kLife_ && il_.list(rdp(m_, life_ + off::LifeState::_entries), litems, ln, 64) && ln) {
            std::vector<uint8_t> raw((size_t)ln * off::LifeEntrySize);
            if (m_.read(litems + il2::ARR_DATA, raw.data(), raw.size())) {
                for (uint32_t i = 0; i < ln; i++) {
                    const uint8_t* e = &raw[(size_t)i * off::LifeEntrySize];
                    int actor, hp;
                    memcpy(&actor, e + off::LifeEntry::Actor, 4);
                    memcpy(&hp, e + off::LifeEntry::Health, 4);
                    bool alive = e[off::LifeEntry::Alive] != 0;
                    life[actor] = {alive ? hp : 0, e[off::LifeEntry::Team]};
                }
                s.lifeOk = true;
            }
        }
    }

    // teammates according to the HUD's own list
    std::vector<int> mateActors;
    {
        bool ok = labels_ && rdp(m_, labels_) == kLabels_;
        if (!ok && n > 0 && now_s() >= nextLabelsScan_) { find_labels(); nextLabelsScan_ = now_s() + 5.0; ok = labels_ != 0; }
        uint64_t mi; uint32_t mn;
        if (ok && il_.list(rdp(m_, labels_ + off::TeammateLabels::_mates), mi, mn, 64) && mn) {
            uint64_t arr[64] = {0};
            if (m_.read(mi + il2::ARR_DATA, arr, mn * 8))
                for (uint32_t i = 0; i < mn; i++) {
                    uint64_t mate = untag(arr[i]);
                    if (!plausible_ptr(mate)) continue;
                    uint64_t ct = rdp(m_, mate + off::Mate::Controller), vw = plausible_ptr(ct) ? rdp(m_, ct + off::PlayerController::_view) : 0;
                    if (plausible_ptr(vw)) mateActors.push_back((int)rd32(m_, vw + off::PhotonView::ownerActorNr));
                }
        }
    }

    for (uint32_t i = 0; i < n; i++) {
        uint64_t cull = untag(ptrs[i]);
        if (!plausible_ptr(cull)) continue;
        uint64_t ctrl = rdp(m_, cull + off::PlayerCulling::_controller);
        uint64_t net  = rdp(m_, cull + off::PlayerCulling::_network);
        if (!plausible_ptr(ctrl) || !plausible_ptr(net)) continue;
        uint64_t view = rdp(m_, ctrl + off::PlayerController::_view);
        if (!plausible_ptr(view)) continue;

        PlayerInfo p;
        p.local = rd8(m_, view + off::PhotonView::IsMine) != 0;
        if (p.local) { localMove_ = rdp(m_, ctrl + off::PlayerController::_movementController); localArms_ = rdp(m_, ctrl + off::PlayerController::_armsController); }
        p.actor = (int)rd32(m_, view + off::PhotonView::ownerActorNr);
        p.dead  = rd8(m_, ctrl + off::PlayerController::_isDeath) != 0;
        p.pos   = rdv<Vec3>(m_, net + off::PlayerNetwork::networkPosition);
        p.vel   = rdv<Vec3>(m_, net + off::PlayerNetwork::_remoteVelocity);
        {
            float q[4];                                   // networkRotation (x,y,z,w) -> yaw
            if (m_.read(net + off::PlayerNetwork::networkRotation, q, sizeof q) && std::isfinite(q[0]) && std::isfinite(q[1]) && std::isfinite(q[2]) && std::isfinite(q[3]))
                p.yaw = std::atan2(2.f * (q[3] * q[1] + q[0] * q[2]), 1.f - 2.f * (q[1] * q[1] + q[2] * q[2])) * 57.29578f;
        }
        p.crouch = (rd8(m_, net + off::PlayerNetwork::_appliedBools) & 2) != 0;   // PlayerNetwork.BoolCrouching
        uint64_t pl = rdp(m_, ctrl + off::PlayerController::_player);
        if (plausible_ptr(pl)) {
            std::string nm = il_.str(rdp(m_, pl + off::Player::nickName));
            strncpy(p.name, nm.c_str(), sizeof p.name - 1);
        }
        for (int a : mateActors) if (a == p.actor) p.mate = true;
        auto it = life.find(p.actor);
        if (it != life.end()) {
            p.hp = it->second.first;
            p.team = it->second.second;
            if (p.hp <= 0) p.dead = true;
        }
        if (!finite3(p.pos) || (p.pos.x == 0 && p.pos.y == 0 && p.pos.z == 0)) continue;   // not spawned yet
        if (p.local) { s.haveLocal = true; s.localActor = p.actor; s.localTeam = p.team; }
        s.players.push_back(p);
    }
    s.valid = true;
    status_ = "ok";
    return true;
}

// ---- weapon mods: zero a few managed floats of the (shared) weapon parameter objects, restore the originals when switched off
void Game::patch_weapons(bool noRecoil, bool noSpread) {
    const double t = now_s();
    if (t < nextWp_) return;
    nextWp_ = t + 1.0;
    if (!noRecoil && !noSpread && saved_.empty()) return;

    auto restore = [&](int cat) {
        for (size_t i = 0; i < saved_.size();) {
            if (saved_[i].cat == cat) { m_.write(saved_[i].addr, &saved_[i].bits, 4); saved_.erase(saved_.begin() + i); }
            else i++;
        }
    };
    if (!noRecoil) restore(1);
    if (!noSpread) restore(2);
    if (!noRecoil && !noSpread) return;

    // (re)find the WeaponParameters objects: once, and again when they vanished
    bool stale = wp_.empty();
    for (uint64_t o : wp_) if (rdp(m_, o) != kWp_) { stale = true; break; }
    if (stale && t >= nextWpScan_) {
        nextWpScan_ = t + 15.0;
        if (!kWp_) kWp_ = il_.klass(off::WeaponParameters::cls);
        wp_.clear();
        if (kWp_)
            wp_ = il_.find_instances(kWp_, [&](uint64_t o) { return plausible_ptr(rdp(m_, o + off::WeaponParameters::_recoilParameters)); });
    }
    auto zero = [&](uint64_t addr, int cat) {
        uint32_t cur = rd32(m_, addr);
        float f; memcpy(&f, &cur, 4);
        if (!std::isfinite(f) || f == 0.f) return;               // already zero (or garbage): nothing to do / nothing to save
        for (auto& s : saved_) if (s.addr == addr) return;
        uint32_t z = 0;
        if (m_.write(addr, &z, 4)) saved_.push_back({addr, cur, cat});
    };
    for (uint64_t o : wp_) {
        if (rdp(m_, o) != kWp_) continue;
        if (noSpread) { zero(o + off::WeaponParameters::_pelletSpread, 2); zero(o + off::WeaponParameters::_scopedMoveInaccuracy, 2); }
        if (noRecoil) {
            uint64_t rp = rdp(m_, o + off::WeaponParameters::_recoilParameters);
            if (!plausible_ptr(rp)) continue;
            zero(rp + off::RecoilParameters::_horizontalRange, 1); zero(rp + off::RecoilParameters::_verticalRange, 1);
            zero(rp + off::RecoilParameters::cameraDeviationCoeff, 1); zero(rp + off::RecoilParameters::_viewKickAngle, 1);
        }
    }
}

// ---- movement mods: bhop statics + noclip flag + speed/jump/gravity multipliers on the LOCAL player's PlayerMovement
void Game::patch_move(const MoveCfg& c) {
    const double t = now_s();
    if (t < nextMv_) return;
    nextMv_ = t + 0.2;
    if (!c.any() && mv_.empty()) return;
    if (!kMove_) kMove_ = il_.klass(off::PlayerMovement::cls);
    if (!kMove_) return;

    auto setv = [&](uint64_t addr, int sz, uint32_t want) {
        uint32_t cur = 0;
        m_.read(addr, &cur, sz);
        if (sz == 1) cur &= 0xFF;
        if (cur == want) return;
        if (!mv_.count(addr)) mv_[addr] = {sz, cur};
        m_.write(addr, &want, sz);
    };
    auto unset = [&](uint64_t addr) {
        auto it = mv_.find(addr);
        if (it == mv_.end()) return;
        m_.write(addr, &it->second.bits, it->second.size);
        mv_.erase(it);
    };
    auto scalef = [&](uint64_t addr, float mul) {
        if (mul == 1.f) { unset(addr); return; }
        uint32_t cur = rd32(m_, addr), ob = mv_.count(addr) ? mv_[addr].bits : cur;
        float f; memcpy(&f, &ob, 4);
        if (!std::isfinite(f)) return;
        float nf = f * mul; uint32_t want; memcpy(&want, &nf, 4);
        setv(addr, 4, want);
    };

    // statics (stable address)
    if (uint64_t st = il_.statics(kMove_)) {
        for (uint32_t o : {off::PlayerMovement::s_AutoBunnyHopping, off::PlayerMovement::s_EnableBunnyHopping}) {
            if (c.bhop) setv(st + o, 1, 1); else unset(st + o);
        }
    }
    // instance: if the local player object changed (respawn / new round) the old one is gone -> forget it WITHOUT writing back
    uint64_t obj = localMove_;
    if (obj != mvOwner_) {
        for (auto it = mv_.begin(); it != mv_.end();)
            if (it->first >= mvOwner_ && it->first < mvOwner_ + 0x400 && mvOwner_) it = mv_.erase(it); else ++it;
        mvOwner_ = obj;
    }
    if (!plausible_ptr(obj) || rdp(m_, obj) != kMove_) return;
    if (c.noclip) setv(obj + off::PlayerMovement::NoclipEnabled, 1, 1); else unset(obj + off::PlayerMovement::NoclipEnabled);
    scalef(obj + off::PlayerMovement::_speed, c.speed);
    scalef(obj + off::PlayerMovement::_jumpStrength, c.jump);
    scalef(obj + off::PlayerMovement::_gravity, c.grav);
}

// ---- code patches: `ret` at the entry of void functions. Addresses come from il2cpp's own method table (no RVAs).
void Game::patch_code(bool noRecoil, bool noSpread) {
    const double t = now_s();
    if (t < nextCode_) return;
    nextCode_ = t + 0.5;
    if (!noRecoil && !noSpread && code_.count() == 0) return;
    if (!kArms_) kArms_ = il_.klass(off::ArmsController::cls);
    if (!kFps_) kFps_ = il_.klass(off::PlayerFPSCamera::cls);
    if (kArms_) {
        if (!addrRecoil_) addrRecoil_ = il_.method_addr(kArms_, "ApplyCameraRecoil", 1);
        if (!addrDisp_) addrDisp_ = il_.method_addr(kArms_, "GetRelativeDispertion", 4);
    }
    if (kFps_) {
        if (!addrKick_) addrKick_ = il_.method_addr(kFps_, "AddShootKick", 0);
        if (!addrShake_) addrShake_ = il_.method_addr(kFps_, "Shake", 3);
    }
    auto sw = [&](uint64_t a, bool on) { if (!a) return; if (on) { if (!code_.has(a)) code_.ret_at(a); } else code_.restore(a); };
    sw(addrRecoil_, noRecoil); sw(addrKick_, noRecoil); sw(addrShake_, noRecoil);
    sw(addrDisp_, noSpread);
}

// ---- arms state: magazine freeze (infinite ammo) and the penetration mask (wallbang)
void Game::patch_arms(bool infAmmo, bool wallbang) {
    if (!infAmmo && !wallbang && ar_.empty()) return;
    if (!kArms_) kArms_ = il_.klass(off::ArmsController::cls);
    uint64_t a = localArms_;
    if (a != armsOwner_) {                               // new local player object: forget old state, never write back to a dead object
        ar_.clear(); armsOwner_ = a; lastWeapon_ = -1; maxMag_ = 0;
    }
    if (!kArms_ || !plausible_ptr(a) || rdp(m_, a) != kArms_) return;
    if (infAmmo) {
        int w = (int)rd32(m_, a + off::ArmsController::_weaponId);
        int16_t mag = rdv<int16_t>(m_, a + off::ArmsController::MagazineCapacity);
        bool reloading = rd8(m_, a + off::ArmsController::isReload) != 0;
        if (w != lastWeapon_) { lastWeapon_ = w; maxMag_ = mag; }
        else if (mag > maxMag_) maxMag_ = mag;
        if (!reloading && mag >= 0 && mag < maxMag_ && maxMag_ <= 300) { int16_t v = (int16_t)maxMag_; m_.write(a + off::ArmsController::MagazineCapacity, &v, 2); }
    }
    uint64_t sm = a + off::ArmsController::shotThroughMask;
    if (wallbang) {
        uint32_t cur = rd32(m_, sm);
        if (cur != 0xFFFFFFFFu) { if (!ar_.count(sm)) ar_[sm] = {4, cur}; uint32_t all = 0xFFFFFFFFu; m_.write(sm, &all, 4); }
    } else if (ar_.count(sm)) { m_.write(sm, &ar_[sm].bits, 4); ar_.erase(sm); }
}

// ---- silent aim detour management
static std::string tidy(std::string s) { for (auto& ch : s) if (ch == ' ' || ch == '|' || ch == ',' || ch == ';') ch = '_'; return s.substr(0, 42); }

void Game::silent_prepare(bool wanted) {
    const double t = now_s();
    if (!wanted) {
        if (fire_.ready() || pell_.ready()) { fire_.uninstall(); pell_.uninstall(); fireOk_ = pellOk_ = false; }
        silentStatus_ = "off";
        return;
    }
    if (fireOk_) return;
    if (t < nextSilent_) return;
    nextSilent_ = t + 3.0;
    if (!kArms_) kArms_ = il_.klass(off::ArmsController::cls);
    if (!kArms_) { silentStatus_ = "no_ArmsController_class"; return; }
    uint64_t fr = il_.method_addr(kArms_, "FireRay", 4), fp = il_.method_addr(kArms_, "FirePellets", 5);
    if (!fr) { silentStatus_ = "FireRay_not_found"; return; }
    std::string err;
    fireOk_ = fire_.install(fr, 3, err);
    if (!fireOk_) { silentStatus_ = "err_" + tidy(err); return; }
    pellOk_ = fp && pell_.install(fp, 4, err);
    silentStatus_ = pellOk_ ? "ok" : "ok_ray_only";
}

void Game::silent_feed(bool on, Vec3 dir) {
    if (!fireOk_) return;
    if (!on) { fire_.off(); if (pellOk_) pell_.off(); return; }
    uint64_t deadline = counter_now() + counter_freq() / 8;          // 125 ms: the detour switches itself off if we stop feeding
    float d[3] = {dir.x, dir.y, dir.z};
    fire_.feed(d, deadline);
    if (pellOk_) { float q[4]; look_quat(dir, q); pell_.feed(q, deadline); }
}

void Game::shutdown_patches() {
    fire_.uninstall(); pell_.uninstall(); fireOk_ = pellOk_ = false;
    code_.restore_all();
    for (auto& kv : mv_) m_.write(kv.first, &kv.second.bits, kv.second.size);
    mv_.clear();
    for (auto& kv : ar_) m_.write(kv.first, &kv.second.bits, kv.second.size);
    ar_.clear();
    for (auto& s : saved_) m_.write(s.addr, &s.bits, 4);
    saved_.clear();
}
