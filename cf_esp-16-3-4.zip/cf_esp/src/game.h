// CounterFlame state reader: one call = one consistent-enough snapshot for the ESP.
#pragma once
#include "code.h"
#include "il2cpp.h"
#include "vmath.h"
#include <map>
#include <string>
#include <vector>

struct PlayerInfo {
    int actor = 0;
    Vec3 pos;                 // feet, world
    Vec3 vel;
    float yaw = 0;            // degrees, Unity convention (0 = +Z, clockwise from above)
    bool local = false, dead = false, crouch = false;
    bool mate = false;        // listed by the game's own TeammateLabels (works even when the life table is not found)
    int hp = 100;
    uint8_t team = 0;         // 0 none, 1 CT, 2 T, 3 spec (LifeState.Team*)
    char name[32] = {0};
};

struct Snapshot {
    bool valid = false;       // camera + player list readable
    Cam cam;
    bool haveLocal = false;
    int localActor = 0;
    uint8_t localTeam = 0;
    bool lifeOk = false;      // hp/team table found
    std::vector<PlayerInfo> players;
};

struct MoveCfg {
    bool bhop = false, noclip = false;
    float speed = 1.f, jump = 1.f, grav = 1.f;      // multipliers of the local PlayerMovement tuning
    bool any() const { return bhop || noclip || speed != 1.f || jump != 1.f || grav != 1.f; }
};

class Game {
public:
    Game(IMem& m, uint64_t il2cppBase) : m_(m), il_(m, il2cppBase) {}
    bool resolve();                 // class pointers; false until the game reached a state where they exist
    bool update(Snapshot& s);
    const char* status() const { return status_.c_str(); }
    int classes_seen() const { return il_.classes_seen(); }
    void set_scan_gap(double s) { il_.set_scan_gap(s); }
    // weapon parameter patches (managed floats of WeaponParameters / RecoilParameters); throttled, reversible
    void patch_weapons(bool noRecoil, bool noSpread);
    void patch_move(const MoveCfg& c);              // local PlayerMovement fields + bhop statics; reversible
    int move_patched() const { return (int)mv_.size(); }
    // code patches (ret on ApplyCameraRecoil / AddShootKick / Shake / GetRelativeDispertion) + arms state (ammo, wallbang mask)
    void patch_code(bool noRecoil, bool noSpread);
    void patch_arms(bool infAmmo, bool wallbang);
    int code_patched() const { return (int)code_.count(); }
    // silent aim: install/remove the detours, and per tick feed the direction (on=false -> normal shots)
    void silent_prepare(bool wanted);
    void silent_feed(bool on, Vec3 dir);
    const char* silent_status() const { return silentStatus_.c_str(); }
    void shutdown_patches();                        // restore everything we changed (called on exit / game close)
    int patched() const { return (int)saved_.size(); }
    int weapons() const { return (int)wp_.size(); }
private:
    bool find_life();
    bool find_labels();
    uint64_t kLabels_ = 0, labels_ = 0;
    double nextLabelsScan_ = 0;
    IMem& m_;
    Il2 il_;
    uint64_t kCull_ = 0, kFps_ = 0, kLife_ = 0;
    uint64_t cullStatics_ = 0, fpsStatics_ = 0;
    uint64_t life_ = 0;             // LifeState instance
    double nextLifeScan_ = 0;
    std::string status_ = "init";
    struct Saved { uint64_t addr; uint32_t bits; int cat; };
    std::vector<Saved> saved_;
    std::vector<uint64_t> wp_;
    uint64_t kWp_ = 0, kMove_ = 0, localMove_ = 0, mvOwner_ = 0;
    struct MvSaved { int size; uint32_t bits; };
    std::map<uint64_t, MvSaved> mv_;
    double nextMv_ = 0, nextCode_ = 0, nextSilent_ = 0;
    uint64_t kArms_ = 0, localArms_ = 0, armsOwner_ = 0;
    int lastWeapon_ = -1, maxMag_ = 0;
    std::map<uint64_t, MvSaved> ar_;
    CodePatcher code_{m_};
    SilentHook fire_{m_, code_}, pell_{m_, code_};
    bool fireOk_ = false, pellOk_ = false;
    std::string silentStatus_ = "off";
    uint64_t addrRecoil_ = 0, addrKick_ = 0, addrShake_ = 0, addrDisp_ = 0;
    double nextWp_ = 0, nextWpScan_ = 0;
};
