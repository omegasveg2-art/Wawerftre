CounterFlame external ESP: root binary (cf_core) reads game memory, APK draws the overlay (public Android APIs only).
Build: GitHub Actions (.github/workflows/build.yml) -> artifact cf_esp.apk. Install, allow overlay, open a match, tap start. INS = menu.
After a game patch: re-dump (Il2CppDumper), `python3 tools/gen_offsets.py dump.cs script.json src/offsets.h`, rebuild.
Host tests: tests/test_core.cpp, tests/test_aim.cpp (native), tests/java/ModelTest.java (parser, prediction, w2s).
Not verified on device: field semantics (game.cpp), aim touch injection (inject.cpp), APK UI code (never compiled against android.jar by the author).
